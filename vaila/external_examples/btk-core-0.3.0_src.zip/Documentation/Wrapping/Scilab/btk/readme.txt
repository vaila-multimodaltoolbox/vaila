readme.txt about btk module

BTK is an open-source and cross-platform library for biomechanical analysis. BTK read and write acquisition file (C3D, TRC, ANC, ...), modify them or compute other parameters (ground reactions forces for examples). 

