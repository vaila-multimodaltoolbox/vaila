#include <cxxtest/TestGenerator.h>

#include "DummyTest.h"