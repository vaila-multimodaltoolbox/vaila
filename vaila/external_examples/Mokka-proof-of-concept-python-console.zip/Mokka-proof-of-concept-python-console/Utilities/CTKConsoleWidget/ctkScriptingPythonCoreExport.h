#ifndef __ctkScriptingPythonCoreExport_h
#define __ctkScriptingPythonCoreExport_h

/* No need to use dynamic symbols as it is included in the code of Mokka and not in a library */
#define CTK_SCRIPTING_PYTHON_CORE_EXPORT

#endif

