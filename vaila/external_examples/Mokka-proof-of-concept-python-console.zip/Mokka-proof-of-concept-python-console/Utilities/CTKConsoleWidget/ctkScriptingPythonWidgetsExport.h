#ifndef __ctkScriptingPythonWidgetsExport_h
#define __ctkScriptingPythonWidgetsExport_h

/* No need to use dynamic symbols as it is included in the code of Mokka and not in a library */
#define CTK_SCRIPTING_PYTHON_WIDGETS_EXPORT

#endif

