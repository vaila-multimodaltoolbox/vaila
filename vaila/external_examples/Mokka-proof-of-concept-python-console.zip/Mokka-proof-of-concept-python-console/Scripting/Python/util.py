def quit():
  from mokka import app
  app.quit()

def exit():
  quit()

def restart():
  from mokka import app
  app.restart()